import java.util.LinkedList;
import java.io.IOException;
import java.util.Scanner;

import static filing.filing.*;


abstract class LibraryItems{
        public static int Library_id;
        public static String Student_name;
        public static String Department;

        public static int category;

        public static String item;
         public static int option_number;

        public static int Book_number;

        public static String add_remove;

        public static String yes_no;

        public static String title;
        public static String titleToRemove;
        private static LinkedList<Book> books;
    private static Scanner scanner;
    //constructor
    public LibraryItems() {
            this.books = new LinkedList<>();
        }
    //method to add books
        public static void addBook(Scanner scanner) {
            System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tEnter the title of the book: ");
            title = scanner.nextLine();
    
            books.add(new Book(title));
        }
    //method to remove books
        public static void removeBook(Scanner scanner) {
            System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tEnter the title of the book you want to remove: ");
            titleToRemove = scanner.nextLine();
    
            // Iterate through the books to find the matching title
            Book bookToRemove = null;
            for (Book book : books) {
                if (book.getTitle().equals(titleToRemove)) {
                    bookToRemove = book;
                    break;
                }
            }
    
            if (bookToRemove != null) {
                books.remove(bookToRemove);
                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tBook removed successfully.");
            } else {
                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tBook not found in the library.");
            }
        }




        public int getId() {
            return Library_id;
        }

        public String getName() {
            return Student_name;
        }
        public String getDepartment() {
            return Department;
        }
        //method that will be overridden in the extended classes 
        public abstract void chooseBook(int Book_number) throws IOException;
        //method to borrow books with the help of filling,switch cases and if else conditions
        public static void Borrow() throws IOException {
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t1. Fiction books");
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t2. Non Fiction books");
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t3. Thriller books");
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t4. DVDS");
                        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tSelect Category : ");
                        //opt1 is an object that stores the value of the variable category
                        Scanner opt1 = new Scanner(System.in);
                        category = opt1.nextInt();
                        //category is a variable that the switch case will use to store the option chosen by the user
                        switch (category)
                        {
                            case 1 :
                                Fiction_books();
                                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tSelect the book you want to borrow");
                                Scanner opt2 = new Scanner(System.in);
                                Book_number = opt2.nextInt();
                                FictionBooks F1 = new FictionBooks();
                                F1.chooseBook(Book_number);
                                if (Book_number == 1)
                                {
                                    item = "Educated";
                                }
                                else if (Book_number == 2){
                                    item = "In Cold Blood";

                                }
                                else if (Book_number == 3) {
                                    item = "Into Thin Air";
                                }
                                else if (Book_number == 4) {
                                    item = "Silent Spring ";
                                }
                                else {
                                    System.out.println("Invaild Input");
                                }
                                break;
                
                            case 2 :
                                Non_fiction_books();
                                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tSelect the book you want to borrow");
                                Scanner opt3 = new Scanner(System.in);
                                Book_number = opt3.nextInt();
                                NonFictionBooks F2 = new NonFictionBooks();
                                F2.chooseBook(Book_number);
                                if (Book_number == 1)
                                {
                                    item = "Elements of Friction Theory and Nanotribology";
                                }
                                else if (Book_number == 2){
                                    item = "Experiments with Friction";

                                }
                                else if (Book_number == 3) {
                                    item = "Focus on Friction";
                                }
                                else if (Book_number == 4) {
                                    item = "What is Friction";
                                }
                                else {
                                    System.out.println("Invaild Input");
                                }
                                break;
                
                            case 3 :
                                Thirller_books();
                                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tSelect the book you want to borrow");
                                Scanner opt4 = new Scanner(System.in);
                                Book_number = opt4.nextInt();
                                ThrillerBooks F3 = new ThrillerBooks();
                                F3.chooseBook(Book_number);
                                if (Book_number == 1)
                                {
                                    item = "Gone Girl";
                                }
                                else if (Book_number == 2){
                                    item = "The Girl on the Train";

                                }
                                else if (Book_number == 3) {
                                    item = "The Silent Patient";
                                }
                                else if (Book_number == 4) {
                                    item = "Verity";
                                }
                                else {
                                    System.out.println("Invaild Input");
                                }
                                break;
                
                            case 4 :
                                DVDs();
                                System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tSelect the book you want to borrow");
                                Scanner opt5 = new Scanner(System.in);
                                Book_number = opt5.nextInt();
                                DVD F4 = new DVD();
                                F4.chooseBook(Book_number);
                                if (Book_number == 1)
                                {
                                    item = "The Biographers Tale";
                                }
                                else if (Book_number == 2){
                                    item = "The Dancing Floor";

                                }
                                else if (Book_number == 3) {
                                    item = "The Dancing Floor";
                                }
                                else if (Book_number == 4) {
                                    item = "The Pearl Driver";
                                }
                                else {
                                    System.out.println("Invaild Input");
                                }
                                break;
                
                            default:
                                System.out.println("Invalid category!");
                
                        }


        }
    //method to print the transcript at the end 
    public static void Transcript()
    {
        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tEnter your your Name ");
        Scanner opt7 = new Scanner(System.in);
        Student_name = opt7.nextLine();
        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tEnter your ID ");
        Scanner opt8 = new Scanner(System.in);
        Library_id = opt8.nextInt();
        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tEnter your Department ");
        Scanner opt9 = new Scanner(System.in);
        Department = opt9.nextLine();


        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t********************\n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t======================================================================\n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                             DSU TRANSCRIPT                                          \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                                                                                     \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                                                                                      \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Name : "+ Student_name);System.out.print("                                           \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Student ID : " + Library_id);System.out.print("                                       \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Department : " +Department);System.out.print( "                                        \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Item Name : "  + item );System.out.print("                                              \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Item Added :" +title);System.out.print( "                                                \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Item Removed :" +titleToRemove);System.out.print("                                         \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                                                                                             \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                                                                                             \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  Note : return the book after                                                               \n" );
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=  10 days to avoid charges                                                                   \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                                                                                             \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t=                               Thank You                                                       \n");
        System.out.print("\t\t\t\t\t\t\t\t\t\t\t\t======================================================================\n" );
        System.out.print("\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t********************");

    }
    //main method
    public static void main(String[] args) throws IOException {
                    //calling the method to print the welcome message
                    Welcome_message();
                    System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tEnter a number : " );
                    //opt is an object that stores the value of the variable option_number
                    Scanner opt = new Scanner(System.in);
                    option_number = opt.nextInt();
                //option_number is a variable that the outer switch case will use to store the option chosen by the user
            switch (option_number){
                        case 1 :
                            System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tFiction Books");
                            Fiction_books();
                            System.out.println("");
                            System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tNon Fiction books");
                            Non_fiction_books();
                            System.out.println("");
                            System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tThriller Books");
                            Thirller_books();
                            System.out.println("");
                            System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tDVDS");
                            DVDs();
                            System.out.println("");
                            System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tDo you want borrow book?");
                            System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tPress Y for Yes Press N for No" );
            
                             String yes_no = opt.next();
                            System.out.println("");
                        //yes_no is a variable that the inner switch case will use to store the option chosen by the user
                        switch (yes_no) {
                             case "Y":
                            Borrow();
                            break;
            
                            case "N":
                            System.out.println("Thankyou for visting Dsu library");
                            break;
            
                            default:
                            System.out.println("Invalid input!");
                            break;
                        }
                        break;
                
            
                    case 2 :
                        Borrow();
                        break;

                        default:
                            System.out.println("Invalid category!");
                            break;
            
                 }

                 System.out.println("");

                System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tDo you want to add book or remove book?");
                System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tPress A to add and R to remove");
                //opt10 is an object that stores the value of the variable add_remove
                Scanner opt10 = new Scanner(System.in);
                add_remove = opt10.nextLine();
                //add_remove is a variable that the switch case will use to store the option chosen by the user
                switch (add_remove){

                    case "A" :
                    {
                        System.out.println("\n\t\t\t\t\t\t\t\t\t\t\t\tHow many books do you want to add?");
                        Scanner scanner = new Scanner(System.in);
                        int numberOfBooks = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character

                        for (int i = 0; i < numberOfBooks; i++) {
                            addBook(scanner);
                        }
                    }
                    break;

                    case "R" :
                    {
                        removeBook(scanner);

                        // the code for printing the remained books
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tbooks added: "+title+" removed books: "+titleToRemove);
                    }
                    break;
                    default:
                        System.out.println("\t\t\t\t\t\t\t\t\t\t\t\tInvaild input");
                }
                Transcript();

        }
}
    // the following extended class holds the overridden method that will show the book chosen by the user with the help of switch case and filling
    //Book_number is the variable that switch uses to choose the book
         class FictionBooks extends LibraryItems {


            @Override
            public void chooseBook(int Book_number) throws IOException {


                switch (Book_number) {
                    case 1:
                        Educated();
                        break;
                    case 2:
                        In_Cold_Blood();
                        break;
                    case 3:
                        Into_Thin_Air();
                        break;
                    case 4:
                        Silent_Spring();
                    break;
                    default:
                        System.out.println("Invalid category selected.");
                        break;
                }
            }
        }

        class NonFictionBooks extends LibraryItems {


            @Override
            public void chooseBook(int Book_number) throws IOException {

                switch (Book_number) {
                    case 1:
                        Elements_of_Friction_Theory_and_Nanotribology();
                        break;
                    case 2:
                        Experiments_with_Friction();
                        break;
                    case 3:
                        Focus_on_Friction();
                        break;
                    case 4:
                        What_is_Friction();
                    break;
                    default:
                        System.out.println("Invalid category selected.");
                        break;
                }
            }
        }

        class ThrillerBooks extends LibraryItems {

            @Override
            public void chooseBook(int Book_number) throws IOException {


                switch (Book_number) {
                    case 1:
                        Gone_Girl();
                        ;
                        break;
                    case 2:
                        The_Girl_on_the_Train();
                        break;
                    case 3:
                        The_Silent_Patient();
                        break;
                    case 4:
                        Verity();
                        break;
                    default:
                        System.out.println("Invalid category selected.");
                        break;

                }
            }

        }

        class DVD extends LibraryItems {


            @Override
            public void chooseBook(int Book_number) throws IOException {


                switch (Book_number) {
                    case 1:
                        The_Biographers_Tale();
                        break;
                    case 2:
                        The_Dancing_Floor();
                        break;
                    case 3:
                        The_New_Testament();
                        break;
                    case 4:
                        The_Pearl_Driver();
                        break;
                    default:
                        System.out.println("Invalid category selected.");
                        break;

                }
            }

}
//this class helps with the add remove functions
class Book {

    private String title;

    public Book(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}


